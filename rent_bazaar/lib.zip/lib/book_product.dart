import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:intl/intl.dart';
import 'package:rent_bazaar/classes/product.dart';
import 'package:rent_bazaar/home.dart';
import 'package:shared_preferences/shared_preferences.dart';

class BookProduct extends StatefulWidget {
  Product bookingProduct;

  BookProduct({
    required this.bookingProduct,
  });

  @override
  State<BookProduct> createState() => _BookProductState();
}

class _BookProductState extends State<BookProduct> {
  String? bookedUntil = "Not Specified";
  final _dayFormatter = DateFormat('d');
  final _monthFormatter = DateFormat('MM');
  final _yearFormatter = DateFormat('yyyy');

  selectBookingEnding(BuildContext context) {
    showDatePicker(
      context: context,
      initialDate: DateTime.now().add(
        Duration(
          days: 2,
        ),
      ),
      //which date will display when user open the picker
      firstDate: DateTime.now().add(
        Duration(
          days: 2,
        ),
      ),
      //what will be the previous supported year in picker
      lastDate: DateTime.now().add(
        Duration(
          days: 30,
        ),
      ),
    ) //what will be the up to supported date in picker
        .then((pickedDate) {
      //then usually do the future job
      if (pickedDate == null) {
        //if user tap cancel then this function will stop
        return;
      }
      setState(() {
        bookedUntil = _dayFormatter.format(pickedDate) +
            '/' +
            _monthFormatter.format(pickedDate) +
            '/' +
            _yearFormatter.format(pickedDate);
      });
    });
  }

  bookNow() async {
    if (bookedUntil != "Not Specified") {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      final productsCollection =
          FirebaseFirestore.instance.collection("products");
      final currentProductDoc = await productsCollection
          .where("imageURL", isEqualTo: widget.bookingProduct.imageURL)
          .get();
      productsCollection.doc(currentProductDoc.docs.first.id).update({
        "bookedBy": prefs.getString("email")!,
        "bookedOn": _dayFormatter.format(
              DateTime.now(),
            ) +
            '/' +
            _monthFormatter.format(
              DateTime.now(),
            ) +
            '/' +
            _yearFormatter.format(
              DateTime.now(),
            ),
        "bookedUntil": bookedUntil,
      }).then(
        (value) {
          Fluttertoast.showToast(msg: "Successfully booked!");
          Navigator.pushAndRemoveUntil(
            context,
            CupertinoPageRoute(
              builder: (_) => HomePage(),
            ),
            (route) => false,
          );
        },
        onError: (e) {
          Fluttertoast.showToast(msg: "Can't rent product, please try later.");
        },
      );
      return true;
    } else {
      Fluttertoast.showToast(
          msg: "Please select an ending date for your booking");
      selectBookingEnding(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(
          color: Colors.red,
        ),
        title: Text(
          "Book ${widget.bookingProduct.title}",
          style: TextStyle(
            color: Colors.black,
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 15.0),
            child: Column(
              children: [
                SizedBox(
                  height: 25,
                ),
                Card(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(
                      10,
                    ),
                  ),
                  child: Column(
                    children: [
                      Align(
                        alignment: Alignment.centerLeft,
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text(
                            "Terms & Conditions",
                            style: TextStyle(
                              color: Colors.black,
                              fontSize: 18,
                              fontFamily: "ProximaBold",
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Padding(
                              padding: const EdgeInsets.only(
                                top: 2.2,
                                right: 5,
                              ),
                              child: Text(
                                "1.",
                                style: TextStyle(
                                  color: Colors.grey,
                                ),
                              ),
                            ),
                            Expanded(
                              child: Text(
                                "Please bring Rs." +
                                    ((25 / 100) *
                                            int.parse(
                                              widget.bookingProduct.averageCost,
                                            ))
                                        .toString() +
                                    " with you when picking up the product",
                                style: TextStyle(
                                  color: Colors.grey,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Padding(
                              padding: const EdgeInsets.only(
                                top: 2.2,
                                right: 5,
                              ),
                              child: Text(
                                "2.",
                                style: TextStyle(
                                  color: Colors.grey,
                                ),
                              ),
                            ),
                            Expanded(
                              child: Text(
                                "If you fail to deliver the product back on day of submission, Extra rent for the next day will be charged.",
                                style: TextStyle(
                                  color: Colors.grey,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Padding(
                              padding: const EdgeInsets.only(
                                top: 2.2,
                                right: 5,
                              ),
                              child: Text(
                                "3.",
                                style: TextStyle(
                                  color: Colors.grey,
                                ),
                              ),
                            ),
                            Expanded(
                              child: Text(
                                "Bring your original CNIC for verification for pickup. Exchange will not happen if a valid CNIC is not presented.",
                                style: TextStyle(
                                  color: Colors.grey,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                GestureDetector(
                  onTap: () {
                    selectBookingEnding(context);
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Row(
                      children: [
                        Text(
                          "Book Until: $bookedUntil",
                          style: TextStyle(
                            color: Colors.red,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Icon(
                          Icons.edit,
                          color: Colors.red,
                          size: 20,
                        ),
                      ],
                    ),
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                InkWell(
                  onTap: bookNow,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 15.0),
                    child: Card(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(
                          100,
                        ),
                      ),
                      color: Colors.red,
                      child: ListTile(
                        title: Center(
                          child: Text(
                            "Book Now",
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 20,
                              color: Colors.white,
                            ),
                          ),
                        ),
                        trailing: Icon(
                          Icons.arrow_right,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
