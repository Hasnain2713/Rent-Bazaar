import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:rent_bazaar/book_product.dart';
import 'package:rent_bazaar/classes/product.dart';
import 'package:rent_bazaar/classes/user.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ProductDetails extends StatefulWidget {
  Product product;

  ProductDetails({required this.product});

  @override
  State<ProductDetails> createState() => _ProductDetailsState();
}

class _ProductDetailsState extends State<ProductDetails> {
  User? owner;
  User? rentee;

  String currentUser = "";

  getOwner() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    setState(() {
      currentUser = preferences.getString("email")!;
    });
    var collection = FirebaseFirestore.instance.collection('users');
    var docSnapshot = await collection
        .where(
          "email",
          isEqualTo: widget.product.userEmail,
        )
        .limit(1)
        .get();
    setState(() {
      owner = User.fromJson(
        docSnapshot.docs.first.data(),
      );
    });
    print(owner!.name);
  }

  getRentee() async {
    if (widget.product.bookedBy != "") {
      var collection = FirebaseFirestore.instance.collection('users');
      var docSnapshot = await collection
          .where(
            "email",
            isEqualTo: widget.product.bookedBy,
          )
          .limit(1)
          .get();
      setState(() {
        rentee = User.fromJson(
          docSnapshot.docs.first.data(),
        );
      });
      print(rentee!.name);
    }
  }

  @override
  void initState() {
    getOwner();
    getRentee();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      floatingActionButton: (owner != null &&
              owner!.email != currentUser &&
              widget.product.bookedBy == "")
          ? FloatingActionButton.extended(
              backgroundColor: Colors.red,
              onPressed: () {
                Navigator.push(
                  context,
                  CupertinoPageRoute(
                    builder: (_) => BookProduct(
                      bookingProduct: widget.product,
                    ),
                  ),
                );
              },
              label: Text("Book Product"),
              icon: Icon(
                Icons.polymer_rounded,
              ),
            )
          : null,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              SizedBox(
                height: 25,
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Card(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(
                      20,
                    ),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(
                              15,
                            ),
                            child: Image.network(
                              widget.product.imageURL,
                              // height: 3,
                            ),
                          ),
                        ),
                        Container(
                          width: MediaQuery.of(context).size.width * 0.9,
                          // color: Colors.grey,
                          margin: EdgeInsets.only(left: 10, right: 10),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              SizedBox(
                                height: 5,
                                // height: MediaQuery.of(context).size.height*0.01,
                              ),
                              Text(
                                maxLines: 2,
                                widget.product.title.toUpperCase(),
                                // _items[index].toString(),
                                style: TextStyle(
                                  overflow: TextOverflow.ellipsis,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 25,
                                  color: Colors.black,
                                ),
                              ),
                              SizedBox(
                                height: 5,
                              ),
                              Text(
                                widget.product.description,
                                style: TextStyle(
                                  color: Colors.grey,
                                  fontSize: 14,
                                ),
                              ),
                              SizedBox(
                                height: 10,
                              ),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Column(
                                    children: [
                                      Text(
                                        "Rs. " + widget.product.rentPerDay,
                                        // _itemNum[index].toString(),
                                        style: TextStyle(
                                          color: Colors.red,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 25,
                                        ),
                                      ),
                                      Text(
                                        "Per Day",
                                        style: TextStyle(
                                            color: Colors.red, fontSize: 10),
                                      ),
                                    ],
                                  ),
                                  Column(
                                    children: [
                                      Text(
                                        "Rs. " +
                                            ((25 / 100) *
                                                    int.parse(
                                                      widget
                                                          .product.averageCost,
                                                    ))
                                                .toString(),
                                        // _itemNum[index].toString(),
                                        style: TextStyle(
                                          color: Colors.red,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 25,
                                        ),
                                      ),
                                      Text(
                                        "Security Deposit",
                                        style: TextStyle(
                                            color: Colors.red, fontSize: 10),
                                      ),
                                    ],
                                  ),
                                ],
                              )
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              ),
              if (owner == null)
                Center(
                  child: CircularProgressIndicator(
                    color: Colors.red,
                  ),
                ),
              if (owner != null && owner!.email != currentUser)
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Card(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(
                        20,
                      ),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Center(
                            child: Text(
                              "Owner Info",
                              style: TextStyle(
                                color: Colors.black,
                                fontWeight: FontWeight.bold,
                                fontSize: 20,
                              ),
                            ),
                          ),
                          ListTile(
                            title: Text(
                              "Name",
                              style: TextStyle(
                                color: Colors.grey,
                                fontSize: 12,
                              ),
                            ),
                            subtitle: Text(
                              owner!.name,
                              style: TextStyle(
                                color: Colors.red,
                                fontSize: 15,
                              ),
                            ),
                          ),
                          ListTile(
                            title: Text(
                              "Email",
                              style: TextStyle(
                                color: Colors.grey,
                                fontSize: 12,
                              ),
                            ),
                            subtitle: Text(
                              owner!.email,
                              style: TextStyle(
                                color: Colors.red,
                                fontSize: 15,
                              ),
                            ),
                          ),
                          ListTile(
                            title: Text(
                              "CNIC Number",
                              style: TextStyle(
                                color: Colors.grey,
                                fontSize: 12,
                              ),
                            ),
                            subtitle: Text(
                              owner!.cnicNumber,
                              style: TextStyle(
                                color: Colors.red,
                                fontSize: 15,
                              ),
                            ),
                          ),
                          ListTile(
                            title: Text(
                              "CNIC Expiry",
                              style: TextStyle(
                                color: Colors.grey,
                                fontSize: 12,
                              ),
                            ),
                            subtitle: Text(
                              owner!.cnicExpiry,
                              style: TextStyle(
                                color: Colors.red,
                                fontSize: 15,
                              ),
                            ),
                          ),
                          ListTile(
                            title: Text(
                              "Address",
                              style: TextStyle(
                                color: Colors.grey,
                                fontSize: 12,
                              ),
                            ),
                            subtitle: Text(
                              owner!.shippingAddress,
                              style: TextStyle(
                                color: Colors.red,
                                fontSize: 15,
                              ),
                            ),
                          ),
                          ListTile(
                            title: Text(
                              "Proof of CNIC",
                              style: TextStyle(
                                color: Colors.grey,
                                fontSize: 12,
                              ),
                            ),
                            subtitle: Column(
                              children: [
                                SizedBox(
                                  height: 10,
                                ),
                                Image.network(
                                  owner!.cnicFront,
                                ),
                                SizedBox(
                                  height: 5,
                                ),
                                Image.network(
                                  owner!.cnicBack,
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              if (owner != null && owner!.email == currentUser)
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Card(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(
                        20,
                      ),
                    ),
                    child: Text(
                      "This Product is owned by you",
                      style: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                        fontSize: 20,
                      ),
                    ),
                  ),
                ),
              if (rentee != null && rentee!.email == currentUser)
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Card(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(
                        20,
                      ),
                    ),
                    child: Text(
                      "This Product is being rented by you",
                      style: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                        fontSize: 20,
                      ),
                    ),
                  ),
                ),
              if (rentee != null && rentee!.email != currentUser)
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Card(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(
                        20,
                      ),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Center(
                            child: Text(
                              "Rentee Info",
                              style: TextStyle(
                                color: Colors.black,
                                fontWeight: FontWeight.bold,
                                fontSize: 20,
                              ),
                            ),
                          ),
                          ListTile(
                            title: Text(
                              "Name",
                              style: TextStyle(
                                color: Colors.grey,
                                fontSize: 12,
                              ),
                            ),
                            subtitle: Text(
                              rentee!.name,
                              style: TextStyle(
                                color: Colors.red,
                                fontSize: 15,
                              ),
                            ),
                          ),
                          ListTile(
                            title: Text(
                              "Email",
                              style: TextStyle(
                                color: Colors.grey,
                                fontSize: 12,
                              ),
                            ),
                            subtitle: Text(
                              rentee!.email,
                              style: TextStyle(
                                color: Colors.red,
                                fontSize: 15,
                              ),
                            ),
                          ),
                          ListTile(
                            title: Text(
                              "CNIC Number",
                              style: TextStyle(
                                color: Colors.grey,
                                fontSize: 12,
                              ),
                            ),
                            subtitle: Text(
                              rentee!.cnicNumber,
                              style: TextStyle(
                                color: Colors.red,
                                fontSize: 15,
                              ),
                            ),
                          ),
                          ListTile(
                            title: Text(
                              "CNIC Expiry",
                              style: TextStyle(
                                color: Colors.grey,
                                fontSize: 12,
                              ),
                            ),
                            subtitle: Text(
                              rentee!.cnicExpiry,
                              style: TextStyle(
                                color: Colors.red,
                                fontSize: 15,
                              ),
                            ),
                          ),
                          ListTile(
                            title: Text(
                              "Address",
                              style: TextStyle(
                                color: Colors.grey,
                                fontSize: 12,
                              ),
                            ),
                            subtitle: Text(
                              rentee!.shippingAddress,
                              style: TextStyle(
                                color: Colors.red,
                                fontSize: 15,
                              ),
                            ),
                          ),
                          ListTile(
                            title: Text(
                              "Proof of CNIC",
                              style: TextStyle(
                                color: Colors.grey,
                                fontSize: 12,
                              ),
                            ),
                            subtitle: Column(
                              children: [
                                SizedBox(
                                  height: 10,
                                ),
                                Image.network(
                                  rentee!.cnicFront,
                                ),
                                SizedBox(
                                  height: 5,
                                ),
                                Image.network(
                                  rentee!.cnicBack,
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
