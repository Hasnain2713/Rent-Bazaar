import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:rent_bazaar/add_product.dart';
import 'package:rent_bazaar/classes/product.dart';
import 'package:rent_bazaar/component/product_card.dart';
import 'package:rent_bazaar/login.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ViewProducts extends StatefulWidget {
  const ViewProducts({super.key});

  @override
  State<ViewProducts> createState() => _ViewProductsState();
}

class _ViewProductsState extends State<ViewProducts> {
  bool ischecked = true;

  String email = "";

  @override
  void initState() {
    super.initState();
    getEmail();
  }

  getEmail() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      email = prefs.getString("email")!;
    });
  }

  Future<List<Product>> getOwnerProducts() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var collection = FirebaseFirestore.instance.collection('products');
    var docSnapshot = await collection
        .where(
          "userEmail",
          isEqualTo: prefs.getString(
            "email",
          ),
        )
        .get();
    List<Product> products = [];
    docSnapshot.docs.forEach((element) {
      Product fetchedProd = Product.fromJson(element.data());
      products.add(fetchedProd);
    });
    return products;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.red),
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: Text(
          "Your Products",
          style: TextStyle(
            color: Colors.black,
          ),
        ),
      ),
      body: FutureBuilder<List<Product>>(
        future: getOwnerProducts(),
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            return GridView.builder(
              gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                maxCrossAxisExtent: 200.00,
                childAspectRatio: 0.85,
                mainAxisSpacing: 1,
                crossAxisSpacing: 0,
              ),
              itemCount: snapshot.data!.length,
              itemBuilder: (context, index) {
                return CardProductWidget(
                  product: snapshot.data![index],
                );
              },
            );
          }
          return Center(
            child: CircularProgressIndicator(
              color: Colors.blue,
            ),
          );
        },
      ),
    );
  }
}
