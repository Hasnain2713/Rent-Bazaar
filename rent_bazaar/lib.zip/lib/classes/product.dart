class Product {
  String title;
  String averageCost;
  String rentPerDay;
  String imageURL;
  String userEmail;
  String description;
  String bookedUntil;
  String bookedOn;
  String bookedBy;

  Product({
    required this.title,
    required this.averageCost,
    required this.rentPerDay,
    required this.imageURL,
    required this.userEmail,
    required this.description,
    required this.bookedUntil,
    required this.bookedOn,
    required this.bookedBy,
  });

  factory Product.fromJson(Map<String, dynamic> json) {
    return Product(
      title: json['title'],
      averageCost: json['averageCost'],
      rentPerDay: json['rentPerDay'],
      imageURL: json['imageURL'],
      userEmail: json['userEmail'],
      description: json['description'],
      bookedUntil: json['bookedUntil'],
      bookedOn: json['bookedOn'],
      bookedBy: json['bookedBy'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      "title": title,
      "averageCost": averageCost,
      "rentPerDay": rentPerDay,
      "imageURL": imageURL,
      "userEmail": userEmail,
      "description": description,
      "bookedUntil": bookedUntil,
      "bookedOn": bookedOn,
      "bookedBy": bookedBy,
    };
  }
}
